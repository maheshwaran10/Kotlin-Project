package com.example.myapplication;

public class ImplementsExample implements InterfaceExample{
    @Override
    public void method1() {
        System.out.println("Hi");
    }
    @Override
    public void method2() {
        System.out.println("Hello");
    }
}
