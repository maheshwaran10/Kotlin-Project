package com.example.myapplication;

public interface InterfaceExample {
    int mahesh=123;
    void method1();
    void method2();

}
