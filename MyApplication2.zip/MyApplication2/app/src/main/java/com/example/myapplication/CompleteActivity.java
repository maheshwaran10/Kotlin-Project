package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class CompleteActivity extends AppCompatActivity {

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_out_right, R.anim.slide_in_left);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete);

        Button day2= findViewById(R.id.day2);
        Button day3= findViewById(R.id.day3);
        Button day4= findViewById(R.id.day4);

        day2.setOnClickListener(view -> {
            Intent i=new Intent(getApplicationContext(),Day2Activity.class);
            startActivity(i);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

        });

        day3.setOnClickListener(view -> {
            Intent i=new Intent(getApplicationContext(),Day3Activity.class);
            startActivity(i);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

        });

        day4.setOnClickListener(view -> {
            Intent i=new Intent(getApplicationContext(),Day4Activity.class);
            startActivity(i);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

        });


    }
}