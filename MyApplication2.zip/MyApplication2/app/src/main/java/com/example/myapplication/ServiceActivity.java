package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class ServiceActivity extends AppCompatActivity implements View.OnClickListener {

    Button start, stop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);
        start = findViewById(R.id.start);
        stop = findViewById(R.id.stop);

        // declaring listeners for the
        // buttons to make them respond
        // correctly according to the process
        start.setOnClickListener(this);
        stop.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        if (view == start) {

            // starting the service
            startService(new Intent(this, CustomService.class));
        }

        // process to be performed
        // if stop button is clicked
        else if (view == stop) {

            // stopping the service
            stopService(new Intent(this, CustomService.class));
        }
    }
}
